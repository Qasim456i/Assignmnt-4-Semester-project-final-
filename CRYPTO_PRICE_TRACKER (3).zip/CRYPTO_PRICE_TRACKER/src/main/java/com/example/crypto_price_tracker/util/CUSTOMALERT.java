package com.example.crypto_price_tracker.util;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.util.Random;

public class CUSTOMALERT {

    private static final String[] QUOTES = {
            "“Money talks, but mine just waves goodbye.”",
            "“Why do they call it a budget? Because ‘Buy More Stuff’ was taken.”",
            "“My wallet is like an onion, opening it makes me cry.”",
            "“I finally figured out what’s wrong with my brain: on the left, nothing is right, and on the right, nothing is left.”",
            "“Money can’t buy happiness, but it’s a lot more comfortable to cry in a Lamborghini.”",
            "“I put my money where my mouth is, but I’m still hungry.”",
            "“Whoever said money doesn’t grow on trees hasn’t met my credit card bill.”",
            "“Why save money for a rainy day when I can spend it on sunny days?”",
            "“If money doesn’t grow on trees, why do banks have branches?”",
            "“I don’t need a hairstylist, I need a financial advisor!”"
    };


    public static void showAlert(String title, String contentText, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(contentText);
        alert.showAndWait();
    }

    public static Stage showScreen(String message) {
        Stage stage = new Stage();
        VBox layout = new VBox(30);
        layout.setAlignment(javafx.geometry.Pos.CENTER);
        layout.setStyle("-fx-background-color: black; -fx-border-width: 2px;");

        Label label = new Label(message);
        label.setStyle("-fx-text-fill: gray; -fx-font-size: 30px;");
        label.setAlignment(javafx.geometry.Pos.CENTER);
        String randomQuote = QUOTES[new Random().nextInt(QUOTES.length)];
        Label quoteLabel = new Label(randomQuote);
        quoteLabel.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-style: italic;");
        quoteLabel.setAlignment(Pos.CENTER);
       layout.getChildren().addAll(label, quoteLabel);
        stage.setScene(new Scene(layout));
        stage.setFullScreen(true);
        return stage;
    }
}
